import { categories, type CategoryId } from '../data/mockData'
type Props = { active: CategoryId; onChange: (id: CategoryId) => void }
export function CategoryTabs({ active, onChange }: Props) {
  return <div className="category-tabs" role="tablist" aria-label="Категории кейсов">
    {categories.map(cat => <button role="tab" aria-selected={active === cat.id} key={cat.id} className={active === cat.id ? 'category-tab selected' : 'category-tab'} onClick={() => onChange(cat.id)}>{cat.label}</button>)}
  </div>
}
