import { X, PackageCheck, ShieldCheck } from 'lucide-react'
import type { CaseItem } from '../data/mockData'
type Props = { item: CaseItem | null; onClose: () => void }
export function CasePreviewModal({ item, onClose }: Props) {
  if (!item) return null
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}>
    <section className="preview-modal" role="dialog" aria-modal="true" aria-labelledby="preview-title">
      <div className="modal-head"><span className="eyebrow">Карточка коллекции</span><button className="icon-button" onClick={onClose} aria-label="Закрыть"><X/></button></div>
      <div className={`preview-art art-${item.category}`}><span>{item.image}</span></div>
      <h2 id="preview-title">{item.name}</h2>
      <p className="preview-subtitle">{item.itemsCount} предмета в коллекции · демонстрационный просмотр</p>
      <div className="preview-meta"><span><PackageCheck size={16}/> {item.itemsCount} предмета</span><strong>{item.price.toLocaleString('ru-RU')} ₽</strong></div>
      <div className="demo-notice"><ShieldCheck size={17}/> Это макет каталога. Покупки, ставки и случайные денежные выигрыши не реализованы.</div>
      <button className="gradient-btn full-btn" onClick={onClose}>Понятно</button>
    </section>
  </div>
}
