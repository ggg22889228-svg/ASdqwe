import { Coins, Plus, Menu, X } from 'lucide-react'
import { useState } from 'react'

type Props = { onQuickFilter: () => void }
export function Header({ onQuickFilter }: Props) {
  const [menuOpen, setMenuOpen] = useState(false)
  const links = ['Кейсы', 'Апгрейд', 'Батлы', 'Контракты', 'Топ игроков']
  return <header className="site-header">
    <div className="header-inner">
      <a className="brand" href="#top" aria-label="CASE-BATTLE"><span className="brand-mark">✦</span><span>CASE<span className="brand-dash">-</span>BATTLE</span></a>
      <nav className={menuOpen ? 'main-nav nav-open' : 'main-nav'}>
        {links.map((link, i) => <a key={link} className={i === 0 ? 'nav-link active' : 'nav-link'} href={i === 0 ? '#cases' : '#demo'} onClick={() => setMenuOpen(false)}>{link}</a>)}
      </nav>
      <div className="header-actions">
        <button className="login-btn" onClick={() => alert('Демо-профиль: авторизация не подключена.')}>Вход / Регистрация</button>
        <div className="balance"><Coins size={16}/><b>0 ₽</b></div>
        <button className="deposit-btn" onClick={() => alert('Пополнение отключено: это демонстрационный интерфейс.')}><Plus size={16}/> Пополнить</button>
        <button className="mobile-menu" aria-label="Открыть меню" onClick={() => setMenuOpen(v => !v)}>{menuOpen ? <X/> : <Menu/>}</button>
      </div>
    </div>
    <div className="header-bottom"><button className="quick-link" onClick={onQuickFilter}>☷ Быстрый фильтр</button><span>ДЕМО-КОЛЛЕКЦИЯ · ВИРТУАЛЬНЫЕ ПРЕДМЕТЫ</span></div>
  </header>
}
