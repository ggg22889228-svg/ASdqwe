import { Github, Send, MessageCircle } from 'lucide-react'
export function Footer() {
  return <footer className="footer" id="footer"><div className="footer-main">
    <div><a className="brand footer-brand" href="#top"><span className="brand-mark">✦</span><span>CASE<span className="brand-dash">-</span>BATTLE</span></a><p className="footer-copy">Игровая коллекция в неоновом оформлении.<br/>Демонстрационный интерфейс.</p></div>
    <div className="footer-links"><a href="#top">О нас</a><a href="#demo">Правила</a><a href="#demo">FAQ</a><a href="mailto:support@example.com">Поддержка</a></div>
    <div className="socials"><a href="#demo" aria-label="Telegram"><Send/></a><a href="#demo" aria-label="Сообщество"><MessageCircle/></a><a href="#demo" aria-label="GitHub"><Github/></a></div>
  </div><div className="footer-bottom"><span>© 2026 CASE-BATTLE UI. Учебный проект.</span><span>18+ · Только демонстрация. Не является азартной игрой.</span></div></footer>
}
