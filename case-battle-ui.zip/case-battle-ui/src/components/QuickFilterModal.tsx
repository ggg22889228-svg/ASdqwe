import { X } from 'lucide-react'
import { categories, type CategoryId } from '../data/mockData'
type Props = { open: boolean; category: CategoryId; sort: string; onCategory: (v: CategoryId) => void; onSort: (v: string) => void; onClose: () => void }
export function QuickFilterModal({ open, category, sort, onCategory, onSort, onClose }: Props) {
  if (!open) return null
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}>
    <section className="filter-modal" role="dialog" aria-modal="true" aria-labelledby="filter-title">
      <div className="modal-head"><div><span className="eyebrow">Настрой каталог</span><h2 id="filter-title">Быстрый фильтр</h2></div><button className="icon-button" onClick={onClose} aria-label="Закрыть"><X/></button></div>
      <label className="field-label" htmlFor="modal-category">Категория</label>
      <select id="modal-category" value={category} onChange={e => onCategory(e.target.value as CategoryId)}>{categories.map(c => <option value={c.id} key={c.id}>{c.label}</option>)}</select>
      <label className="field-label" htmlFor="modal-sort">Сортировка</label>
      <select id="modal-sort" value={sort} onChange={e => onSort(e.target.value)}><option value="default">По умолчанию</option><option value="asc">Сначала дешевле</option><option value="desc">Сначала дороже</option><option value="name">По названию</option></select>
      <button className="gradient-btn full-btn" onClick={onClose}>Показать результаты</button>
    </section>
  </div>
}
