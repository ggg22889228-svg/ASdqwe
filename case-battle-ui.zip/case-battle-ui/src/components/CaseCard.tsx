import { Heart, Package, Sparkles } from 'lucide-react'
import type { CaseItem } from '../data/mockData'
type Props = { item: CaseItem; favorite: boolean; onFavorite: (id: string) => void; onOpen: (item: CaseItem) => void }
export function CaseCard({ item, favorite, onFavorite, onOpen }: Props) {
  return <article className="case-card">
    <button className={favorite ? 'favorite-btn is-favorite' : 'favorite-btn'} aria-label={favorite ? 'Убрать из избранного' : 'В избранное'} onClick={() => onFavorite(item.id)}><Heart size={17} fill={favorite ? 'currentColor' : 'none'}/></button>
    <div className={`case-art art-${item.category}`}><div className="art-glow"/><span className="case-emoji">{item.image}</span><span className="art-spark"><Sparkles size={17}/></span></div>
    <div className="case-info"><div className="case-name-row"><h3>{item.name}</h3><span className="case-count"><Package size={12}/>{item.itemsCount}</span></div>
      <div className="case-card-bottom"><strong className="case-price">{item.price.toLocaleString('ru-RU')} ₽</strong><button className="open-case-btn" onClick={() => onOpen(item)}>Смотреть <span>↗</span></button></div>
    </div>
  </article>
}
