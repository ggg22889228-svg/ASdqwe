export type CategoryId = 'all' | 'series' | 'image' | 'brand' | 'knives' | 'limited' | 'bonus' | 'operations' | 'valve'

export interface CaseItem {
  id: string
  name: string
  category: Exclude<CategoryId, 'all'>
  itemsCount: number
  price: number
  image: string
  isFavorite: boolean
}

export const categories: { id: CategoryId; label: string }[] = [
  { id: 'all', label: 'Все кейсы' },
  { id: 'series', label: 'Серийные кейсы' },
  { id: 'image', label: 'Имидж-кейсы' },
  { id: 'brand', label: 'Фирменные кейсы' },
  { id: 'knives', label: 'Ножевые кейсы' },
  { id: 'limited', label: 'Ограниченная серия' },
  { id: 'bonus', label: 'Бонусные кейсы' },
  { id: 'operations', label: 'Операции' },
  { id: 'valve', label: 'Valve CS2' },
]

// Цены и карточки — демонстрационные данные, не реальные предложения.
export const mockCases: CaseItem[] = [
  {
    "id": "series-1",
    "name": "Чужой",
    "category": "series",
    "itemsCount": 44,
    "price": 39,
    "image": "📦",
    "isFavorite": false
  },
  {
    "id": "series-2",
    "name": "Гремлин",
    "category": "series",
    "itemsCount": 38,
    "price": 59,
    "image": "🧪",
    "isFavorite": false
  },
  {
    "id": "series-3",
    "name": "Крик",
    "category": "series",
    "itemsCount": 52,
    "price": 79,
    "image": "🧿",
    "isFavorite": false
  },
  {
    "id": "series-4",
    "name": "Пила",
    "category": "series",
    "itemsCount": 36,
    "price": 119,
    "image": "🎭",
    "isFavorite": false
  },
  {
    "id": "series-5",
    "name": "Чаки",
    "category": "series",
    "itemsCount": 48,
    "price": 149,
    "image": "⚡",
    "isFavorite": false
  },
  {
    "id": "series-6",
    "name": "Коэн",
    "category": "series",
    "itemsCount": 41,
    "price": 199,
    "image": "🦇",
    "isFavorite": false
  },
  {
    "id": "image-1",
    "name": "Лакра",
    "category": "image",
    "itemsCount": 44,
    "price": 249,
    "image": "💠",
    "isFavorite": false
  },
  {
    "id": "image-2",
    "name": "Ксанте",
    "category": "image",
    "itemsCount": 38,
    "price": 349,
    "image": "🔮",
    "isFavorite": false
  },
  {
    "id": "image-3",
    "name": "Бренсис",
    "category": "image",
    "itemsCount": 52,
    "price": 399,
    "image": "🗝️",
    "isFavorite": false
  },
  {
    "id": "image-4",
    "name": "The Blood of Dawnwalker",
    "category": "image",
    "itemsCount": 36,
    "price": 499,
    "image": "🌌",
    "isFavorite": false
  },
  {
    "id": "image-5",
    "name": "Lonestar",
    "category": "image",
    "itemsCount": 48,
    "price": 699,
    "image": "🪙",
    "isFavorite": false
  },
  {
    "id": "image-6",
    "name": "Valkyra",
    "category": "image",
    "itemsCount": 41,
    "price": 899,
    "image": "🧊",
    "isFavorite": false
  },
  {
    "id": "brand-1",
    "name": "Manticore",
    "category": "brand",
    "itemsCount": 44,
    "price": 999,
    "image": "📦",
    "isFavorite": false
  },
  {
    "id": "brand-2",
    "name": "Kolchia",
    "category": "brand",
    "itemsCount": 38,
    "price": 1499,
    "image": "🧪",
    "isFavorite": false
  },
  {
    "id": "brand-3",
    "name": "Wardogs",
    "category": "brand",
    "itemsCount": 52,
    "price": 1999,
    "image": "🧿",
    "isFavorite": false
  },
  {
    "id": "brand-4",
    "name": "Эйнштейн",
    "category": "brand",
    "itemsCount": 36,
    "price": 2499,
    "image": "🎭",
    "isFavorite": false
  },
  {
    "id": "brand-5",
    "name": "Менделеев",
    "category": "brand",
    "itemsCount": 48,
    "price": 2999,
    "image": "⚡",
    "isFavorite": false
  },
  {
    "id": "brand-6",
    "name": "Дарвин",
    "category": "brand",
    "itemsCount": 41,
    "price": 3499,
    "image": "🦇",
    "isFavorite": false
  },
  {
    "id": "knives-1",
    "name": "Гаусс",
    "category": "knives",
    "itemsCount": 44,
    "price": 3999,
    "image": "💠",
    "isFavorite": false
  },
  {
    "id": "knives-2",
    "name": "Коперник",
    "category": "knives",
    "itemsCount": 38,
    "price": 4999,
    "image": "🔮",
    "isFavorite": false
  },
  {
    "id": "knives-3",
    "name": "Тёмный клинок",
    "category": "knives",
    "itemsCount": 52,
    "price": 549,
    "image": "🗝️",
    "isFavorite": false
  },
  {
    "id": "knives-4",
    "name": "Лунный резец",
    "category": "knives",
    "itemsCount": 36,
    "price": 649,
    "image": "🌌",
    "isFavorite": false
  },
  {
    "id": "knives-5",
    "name": "Фантом",
    "category": "knives",
    "itemsCount": 48,
    "price": 749,
    "image": "🪙",
    "isFavorite": false
  },
  {
    "id": "knives-6",
    "name": "Кристалл",
    "category": "knives",
    "itemsCount": 41,
    "price": 1099,
    "image": "🧊",
    "isFavorite": false
  },
  {
    "id": "limited-1",
    "name": "Полярная ночь",
    "category": "limited",
    "itemsCount": 44,
    "price": 1299,
    "image": "📦",
    "isFavorite": false
  },
  {
    "id": "limited-2",
    "name": "Красный код",
    "category": "limited",
    "itemsCount": 38,
    "price": 1599,
    "image": "🧪",
    "isFavorite": false
  },
  {
    "id": "limited-3",
    "name": "Золотой час",
    "category": "limited",
    "itemsCount": 52,
    "price": 1799,
    "image": "🧿",
    "isFavorite": false
  },
  {
    "id": "limited-4",
    "name": "Арктика",
    "category": "limited",
    "itemsCount": 36,
    "price": 2199,
    "image": "🎭",
    "isFavorite": false
  },
  {
    "id": "limited-5",
    "name": "Последний рубеж",
    "category": "limited",
    "itemsCount": 48,
    "price": 2699,
    "image": "⚡",
    "isFavorite": false
  },
  {
    "id": "limited-6",
    "name": "Сингулярность",
    "category": "limited",
    "itemsCount": 41,
    "price": 3199,
    "image": "🦇",
    "isFavorite": false
  },
  {
    "id": "bonus-1",
    "name": "Первый шаг",
    "category": "bonus",
    "itemsCount": 44,
    "price": 89,
    "image": "💠",
    "isFavorite": false
  },
  {
    "id": "bonus-2",
    "name": "Ежедневный бонус",
    "category": "bonus",
    "itemsCount": 38,
    "price": 129,
    "image": "🔮",
    "isFavorite": false
  },
  {
    "id": "bonus-3",
    "name": "Искра",
    "category": "bonus",
    "itemsCount": 52,
    "price": 179,
    "image": "🗝️",
    "isFavorite": false
  },
  {
    "id": "bonus-4",
    "name": "Подарок",
    "category": "bonus",
    "itemsCount": 36,
    "price": 229,
    "image": "🌌",
    "isFavorite": false
  },
  {
    "id": "bonus-5",
    "name": "Сюрприз",
    "category": "bonus",
    "itemsCount": 48,
    "price": 279,
    "image": "🪙",
    "isFavorite": false
  },
  {
    "id": "bonus-6",
    "name": "Разминка",
    "category": "bonus",
    "itemsCount": 41,
    "price": 329,
    "image": "🧊",
    "isFavorite": false
  },
  {
    "id": "operations-1",
    "name": "Операция Феникс",
    "category": "operations",
    "itemsCount": 44,
    "price": 449,
    "image": "📦",
    "isFavorite": false
  },
  {
    "id": "operations-2",
    "name": "Гидра",
    "category": "operations",
    "itemsCount": 38,
    "price": 599,
    "image": "🧪",
    "isFavorite": false
  },
  {
    "id": "operations-3",
    "name": "Сломанный клык",
    "category": "operations",
    "itemsCount": 52,
    "price": 799,
    "image": "🧿",
    "isFavorite": false
  },
  {
    "id": "operations-4",
    "name": "Хищные воды",
    "category": "operations",
    "itemsCount": 36,
    "price": 1199,
    "image": "🎭",
    "isFavorite": false
  },
  {
    "id": "operations-5",
    "name": "Авангард",
    "category": "operations",
    "itemsCount": 48,
    "price": 1399,
    "image": "⚡",
    "isFavorite": false
  },
  {
    "id": "operations-6",
    "name": "Расколотая сеть",
    "category": "operations",
    "itemsCount": 41,
    "price": 1899,
    "image": "🦇",
    "isFavorite": false
  },
  {
    "id": "valve-1",
    "name": "Революция",
    "category": "valve",
    "itemsCount": 44,
    "price": 2299,
    "image": "💠",
    "isFavorite": false
  },
  {
    "id": "valve-2",
    "name": "Грезы и кошмары",
    "category": "valve",
    "itemsCount": 38,
    "price": 2799,
    "image": "🔮",
    "isFavorite": false
  },
  {
    "id": "valve-3",
    "name": "Змеиный укус",
    "category": "valve",
    "itemsCount": 52,
    "price": 3699,
    "image": "🗝️",
    "isFavorite": false
  },
  {
    "id": "valve-4",
    "name": "Грёзы",
    "category": "valve",
    "itemsCount": 36,
    "price": 4499,
    "image": "🌌",
    "isFavorite": false
  },
  {
    "id": "valve-5",
    "name": "Галерея",
    "category": "valve",
    "itemsCount": 48,
    "price": 5999,
    "image": "🪙",
    "isFavorite": false
  },
  {
    "id": "valve-6",
    "name": "Киловатт",
    "category": "valve",
    "itemsCount": 41,
    "price": 6999,
    "image": "🧊",
    "isFavorite": false
  }
];
