import { useMemo, useState } from 'react'
import { Search, SlidersHorizontal, Heart, Sparkles, ChevronDown, Boxes } from 'lucide-react'
import { Header } from './components/Header'
import { CategoryTabs } from './components/CategoryTabs'
import { CaseCard } from './components/CaseCard'
import { QuickFilterModal } from './components/QuickFilterModal'
import { CasePreviewModal } from './components/CasePreviewModal'
import { Footer } from './components/Footer'
import { mockCases, type CaseItem, type CategoryId } from './data/mockData'

type SortMode = 'default' | 'asc' | 'desc' | 'name'
const FAVORITES_KEY = 'case-battle-favorites-v1'

function readFavorites(): string[] {
  try { return JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]') as string[] } catch { return [] }
}

export default function App() {
  const [category, setCategory] = useState<CategoryId>('all')
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<SortMode>('default')
  const [favorites, setFavorites] = useState<string[]>(readFavorites)
  const [favoritesOnly, setFavoritesOnly] = useState(false)
  const [quickOpen, setQuickOpen] = useState(false)
  const [selectedCase, setSelectedCase] = useState<CaseItem | null>(null)

  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase('ru')
    const result = mockCases.filter(item =>
      (category === 'all' || item.category === category) &&
      (!favoritesOnly || favorites.includes(item.id)) &&
      (!normalized || item.name.toLocaleLowerCase('ru').includes(normalized))
    )
    if (sort === 'asc') result.sort((a,b) => a.price - b.price)
    if (sort === 'desc') result.sort((a,b) => b.price - a.price)
    if (sort === 'name') result.sort((a,b) => a.name.localeCompare(b.name, 'ru'))
    return result
  }, [category, query, sort, favoritesOnly, favorites])

  function toggleFavorite(id: string) {
    setFavorites(current => {
      const next = current.includes(id) ? current.filter(x => x !== id) : [...current, id]
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(next))
      return next
    })
  }
  function changeCategory(id: CategoryId) { setCategory(id); setFavoritesOnly(false) }

  return <div id="top" className="app-shell">
    <Header onQuickFilter={() => setQuickOpen(true)} />
    <main>
      <section className="hero container">
        <div className="hero-copy">
          <div className="hero-kicker"><span className="live-dot"/> НОВАЯ ЭРА КОЛЛЕКЦИЙ <span className="kicker-line"/></div>
          <h1>У НАС <span>ВЫИГРЫВАЮТ</span><br/>СТИЛЬ И АТМОСФЕРА</h1>
          <p>Открой для себя коллекцию тематических кейсов, изучай предметы и собирай собственную витрину.</p>
          <div className="hero-actions"><a className="gradient-btn" href="#cases">Начать играть <span>↗</span></a><a className="subtle-btn" href="#favorites">Избранное <Heart size={16}/></a></div>
          <div className="hero-footnote"><span><i/> Демо-режим</span><span>Виртуальные предметы без ставок и платежей</span></div>
        </div>
        <div className="hero-visual" aria-hidden="true"><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-halo"/><div className="hero-crate">📦</div><div className="float-chip chip-a">✦ COLLECTION</div><div className="float-chip chip-b">CS2 STYLE</div><div className="visual-caption"><span>CASE</span><b>DROP ZONE</b></div></div>
      </section>

      <section className="ticker-wrap"><div className="ticker"><span>✦ CASE COLLECTION</span><span>✦ NEON SERIES</span><span>✦ DIGITAL ITEMS</span><span>✦ CASE COLLECTION</span><span>✦ NEON SERIES</span><span>✦ DIGITAL ITEMS</span></div></section>

      <section className="catalog container" id="cases">
        <div className="section-title-row"><div><div className="section-overline">ТВОЯ СЛЕДУЮЩАЯ НАХОДКА</div><h2>Каталог <span>кейсов</span></h2><p>Выбирай тематику и изучай доступные коллекции</p></div><div className="catalog-count"><b>{filtered.length.toString().padStart(2,'0')}</b><span>КОЛЛЕКЦИЙ</span></div></div>
        <CategoryTabs active={category} onChange={changeCategory}/>
        <div className="toolbar">
          <div className="search-box"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Поиск кейса..." aria-label="Поиск кейса"/>{query && <button onClick={() => setQuery('')} aria-label="Очистить поиск">×</button>}</div>
          <div className="toolbar-right"><button className={favoritesOnly ? 'favorite-filter active' : 'favorite-filter'} onClick={() => setFavoritesOnly(v => !v)}><Heart size={15} fill={favoritesOnly ? 'currentColor' : 'none'}/> Избранное <span>{favorites.length}</span></button><label className="sort-select"><SlidersHorizontal size={15}/><select value={sort} onChange={e => setSort(e.target.value as SortMode)} aria-label="Сортировка"><option value="default">Сначала популярные</option><option value="asc">Сначала дешевле</option><option value="desc">Сначала дороже</option><option value="name">По названию</option></select><ChevronDown size={14}/></label><button className="quick-filter-btn" onClick={() => setQuickOpen(true)}>Фильтр <SlidersHorizontal size={15}/></button></div>
        </div>
        {filtered.length ? <div className="case-grid">{filtered.map(item => <CaseCard key={item.id} item={item} favorite={favorites.includes(item.id)} onFavorite={toggleFavorite} onOpen={setSelectedCase}/>)}</div> :
          <div className="empty-state"><div className="empty-icon"><Boxes size={30}/></div><h3>{favoritesOnly ? 'Избранное пока пусто' : 'Ничего не найдено'}</h3><p>{favoritesOnly ? 'Ваш список избранного пуст. Зайдя на страницу любого кейса, Вы можете добавить его в Избранное.' : 'Попробуйте изменить запрос или выбрать другую категорию.'}</p><button className="subtle-btn" onClick={() => { setFavoritesOnly(false); setQuery(''); setCategory('all') }}>Сбросить фильтры</button></div>}
      </section>

      <section className="favorites-info container" id="favorites"><div className="favorites-icon"><Heart size={22}/></div><div><div className="section-overline">ЛИЧНАЯ ПОДБОРКА</div><h2>Твоё <span>избранное</span></h2><p>{favorites.length ? `В избранном ${favorites.length} ${favorites.length === 1 ? 'кейс' : 'кейсов'}. Нажми «Избранное» над каталогом, чтобы посмотреть подборку.` : 'Ваш список избранного пуст. Зайдя на страницу любого кейса, Вы можете добавить его в Избранное.'}</p></div><button className="outline-btn" onClick={() => { setFavoritesOnly(true); setCategory('all'); document.querySelector('#cases')?.scrollIntoView({behavior:'smooth'}) }}>Открыть список <span>→</span></button></section>

      <section className="bottom-cta container" id="demo"><div className="cta-glow"/><div className="cta-icon"><Sparkles size={25}/></div><div><div className="section-overline">СОБЕРИ СВОЮ КОЛЛЕКЦИЮ</div><h2>Твой стиль. Твои <span>правила.</span></h2><p>Изучай каталог и сохраняй любимые кейсы.</p></div><a className="gradient-btn" href="#cases">К каталогу <span>↗</span></a></section>
    </main>
    <Footer/>
    <QuickFilterModal open={quickOpen} category={category} sort={sort} onCategory={changeCategory} onSort={v => setSort(v as SortMode)} onClose={() => setQuickOpen(false)}/>
    <CasePreviewModal item={selectedCase} onClose={() => setSelectedCase(null)}/>
  </div>
}
